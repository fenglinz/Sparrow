If `git clone --recursive` was not used, please run `git submodule init; git submodule update` to pull fonttools code.

Note: python 2.6 for 32-bit is required to run ttx.
