'use strict';
//#if TRUE
//#error "Some Error"
//#endif
var b;
