'use strict';
//#if TRUE
var a;
//#else
var b;
//#endif
